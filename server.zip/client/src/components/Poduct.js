import UsefetchData from '../hooks/UsefetchData';
import ProductCard from './ProductCard';

function Product() {
  const token =  localStorage.getItem('token');
  console.log(token)
  const { product, isloading, error } = UsefetchData(
    'http://localhost:3000/products',
    token
  );
  
  if (!token) {
    return <p>You need to log in to view this page. </p>;
  }
  if (isloading) return <div className="text-center text-xl font-bold mt-10">Loading....</div>;
  if (error) return <div className="text-center text-xl font-bold text-red-500 mt-10">{error}</div>;
  console.log(product);
  return (
    <div className="min-h-screen bg-gray-100 p-8 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
      {product?.map(pr=>(
          <ProductCard key={pr.id} title={pr.title} price={pr.price} description={pr.description} image={pr.image}/>
      ))}
     </div>
  );
}

export default Product;