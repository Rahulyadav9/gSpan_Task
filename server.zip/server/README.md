move into server 
do 
npm install
node app
 http://localhost:3000
 