import { useState, useEffect } from "react";

export default function UsefetchData(url, token) {
  const [product, setProduct] = useState(null);
  const [isloading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function fetchData() {
      try {
        const response = await fetch(url, {
          headers: {
            Authorization: `Bearer ${token}`, // Add token to headers
          },
        });
        if (!response.ok) {
          throw new Error("Failed to fetch data");
        }
        const data = await response.json();
        setProduct(data.data);
      } catch (err) {
        setError(err);
      } finally {
        setLoading(false);
      }
    }

    if (token) { // Ensure token is available before making the request
      fetchData();
    }
  }, [url, token]);

  return { product, isloading, error };
}
