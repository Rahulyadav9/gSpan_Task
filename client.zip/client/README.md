move into directory using below commond
 cd client
 npm install 
 npm start
 http://localhost:3001/
